package lca.lca2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lca2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Lca2023Application.class, args);
	}

}
